# KostLang
Creating a simple languge using ANTLR 
